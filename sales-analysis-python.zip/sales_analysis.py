import pandas as pd

# Load dataset
df = pd.read_csv("sales_data.csv")

# Total Sales
total_sales = df["Sales"].sum()
print(f"Total Sales: ₹{total_sales}")

# Average Order Value
average_order = df["Sales"].mean()
print(f"Average Order Value: ₹{average_order:.2f}")

# Sales by Region
sales_by_region = df.groupby("Region")["Sales"].sum()
print("\nSales by Region:")
print(sales_by_region)
