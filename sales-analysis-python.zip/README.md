# 🧾 Sales Analysis with Python

This project uses `pandas` to analyze retail sales data. Key insights include:

- 📊 Total and average sales
- 🌍 Sales by region
- 🧠 Data-driven decisions with Python

## 💻 Technologies
- Python
- Pandas
- CSV data

## 📁 Files
- `sales_data.csv`: Sample dataset
- `sales_analysis.py`: Analysis script
